"""
NLP and structured heuristic message parser for financial updates in messages.csv.
Extracts confirmed payroll revisions, date shifts, contract terminations,
rent changes, and unconfirmed pending flags.
"""

import re
from typing import List, Dict, Any, Optional
from datetime import datetime

from .models import MessageRecord, FinancialEvent


class ParsedMessageInfo:
    def __init__(self):
        self.salary_override_amount: Optional[float] = None
        self.salary_currency: Optional[str] = None
        self.salary_effective_date: Optional[str] = None
        self.salary_ended: bool = False
        self.one_time_salary_adjustment: float = 0.0
        self.rent_increase_percent: Optional[float] = None
        self.ignore_bonus: bool = False
        self.unrealized_investment: bool = False
        self.failed_debit_retry_expected: bool = False
        self.notes: List[str] = []


class MessageParser:
    def __init__(self):
        pass

    def parse_messages_for_user(self, messages: List[MessageRecord]) -> ParsedMessageInfo:
        info = ParsedMessageInfo()
        # Sort messages chronologically by sent_at
        sorted_msgs = sorted(messages, key=lambda m: m.sent_at)

        for msg in sorted_msgs:
            text = msg.message_text
            self._parse_single_message(text, info)

        return info

    def _parse_single_message(self, text: str, info: ParsedMessageInfo):
        # 1. Salary / Employment Termination
        if re.search(r"employment has ended|contract has ended|sumber pendapatan.*telah berakhir", text, re.IGNORECASE):
            # Check if there is remaining confirmed salary mentioned
            rem_match = re.search(r"(?:sisa gaji|confirmed salary|monthly pay).*?(?:is|adalah)\s*(?:[A-Z]{3}|IDR|INR|EUR|USD|ZAR)?\s*([\d\.,]+)", text, re.IGNORECASE)
            if rem_match:
                amt_str = rem_match.group(1).replace(",", "")
                try:
                    info.salary_override_amount = float(amt_str)
                except ValueError:
                    pass
            else:
                info.salary_ended = True

        # 2. Confirmed Salary Update / Pay Revision
        # English patterns:
        # "Your temporary monthly pay is EUR 1037.52."
        # "Your salary of USD 1680 is confirmed for 2025-11-15."
        # "Your next salary is reduced to EUR 1422.85."
        # "Your first salary will be INR 214000."
        # "Your first salary of ZAR 38280 is scheduled for 2025-11-15."
        # "Regular salary of EUR 2717 resumes on 2025-08-15."
        # "Your confirmed base salary is USD 1548."
        # "Your regular salary for the next payroll is INR 103000. The same payroll includes a one-time arrears adjustment of INR 46350."
        
        # Indonesian patterns:
        # "Gaji bulanan Anda naik menjadi IDR 42750000. Perubahan ini berlaku mulai 2025-08-15."
        # "Gaji pokok yang dikonfirmasi adalah IDR 38760000."
        # "Gaji bulanan yang dikonfirmasi adalah IDR 48260000."

        salary_patterns = [
            r"(?:gaji bulanan Anda naik menjadi|gaji pokok yang dikonfirmasi adalah|sisa gaji bulanan yang dikonfirmasi adalah)\s*(?:IDR|INR|EUR|USD|ZAR)?\s*([\d\.,]+)",
            r"(?:temporary monthly pay is|salary of|next salary is reduced to|first salary will be|first salary of|regular salary of|confirmed base salary is|regular salary for the next payroll is)\s*([A-Z]{3}|IDR|INR|EUR|USD|ZAR)?\s*([\d\.,]+)",
            r"(?:salary|gaji).*?(?:is|adalah|menjadi)\s*([A-Z]{3}|IDR|INR|EUR|USD|ZAR)?\s*([\d\.,]+)"
        ]

        # Date pattern for salary:
        date_match = re.search(r"(?:berlaku mulai|expected on|confirmed for|scheduled for|credit date is|resumes on)\s*(\d{4}-\d{2}-\d{2})", text, re.IGNORECASE)
        if date_match:
            info.salary_effective_date = date_match.group(1)

        # Arrears adjustment
        arrears_match = re.search(r"(?:one-time arrears adjustment of|penyesuaian satu kali)\s*([A-Z]{3}|IDR|INR|EUR|USD|ZAR)?\s*([\d\.,]+)", text, re.IGNORECASE)
        if arrears_match:
            amt_str = arrears_match.group(2).replace(",", "")
            try:
                info.one_time_salary_adjustment = float(amt_str)
            except ValueError:
                pass

        for pat in salary_patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                # find the number in groups
                groups = [g for g in m.groups() if g and re.search(r"\d", g)]
                if groups:
                    amt_str = groups[0].replace(",", "")
                    try:
                        info.salary_override_amount = float(amt_str)
                        # currency if present
                        curr_groups = [g for g in m.groups() if g and g in ("INR", "ZAR", "IDR", "USD", "EUR")]
                        if curr_groups:
                            info.salary_currency = curr_groups[0]
                        break
                    except ValueError:
                        pass

        # 3. Rent Increase
        rent_match = re.search(r"renewed lease increases monthly rent by\s*(\d+(?:\.\d+)?)%", text, re.IGNORECASE)
        if rent_match:
            info.rent_increase_percent = float(rent_match.group(1))

        # 4. Failed Debit Retry
        if re.search(r"debit attempt failed.*?another debit will be attempted", text, re.IGNORECASE):
            info.failed_debit_retry_expected = True

        # 5. Pending bonus / commission / contest prize / market value
        if re.search(r"bonus kuartalan|quarterly bonus|commission shown|payout is still pending|prize claim|displayed market value", text, re.IGNORECASE):
            info.ignore_bonus = True
