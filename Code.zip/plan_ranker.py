"""
Plan ranker implementing the strict 6-level tie-breaking hierarchy.
"""

from typing import List
from .models import PlanCandidate


class PlanRanker:
    @staticmethod
    def rank_plans(candidates: List[PlanCandidate]) -> List[PlanCandidate]:
        """
        Ranks eligible safe candidates according to:
        1. Complete by desired_completion_date (True before False).
        2. Require no spending changes (0 changes before 1, 2, 3).
        3. Minimize total amount paid (total_cost ascending).
        4. Start payment earlier (start_date ascending).
        5. Use fewer payments (num_payments ascending).
        6. Lowest payment_option_id tie-breaker.
        """
        def rank_key(p: PlanCandidate):
            return (
                0 if p.completes_by_deadline else 1,
                p.spending_changes_count,
                round(p.total_cost, 2),
                p.start_date,
                p.num_payments,
                p.payment_option_id
            )

        return sorted(candidates, key=rank_key)
