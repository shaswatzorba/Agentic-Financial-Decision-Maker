"""
Token usage tracking and cost report generation for Buy or Wait.
Produces evaluation/usage_report.md in compliance with Challenge §6.5.
"""

from pathlib import Path
from typing import Dict, List, Any
import time

from .config import USAGE_REPORT_PATH, EVALUATION_DIR


class TokenTracker:
    def __init__(self):
        self.provider = "Google DeepMind"
        self.model_name = "Gemini 3.7 Flash & Deterministic Hybrid Engine"
        self.total_requests = 0
        self.model_calls = 0
        self.input_tokens = 0
        self.output_tokens = 0
        self.start_time = time.time()
        self.end_time = None

    def record_request(self, input_toks: int = 0, output_toks: int = 0, calls: int = 1):
        self.total_requests += 1
        self.model_calls += calls
        self.input_tokens += input_toks
        self.output_tokens += output_toks

    def generate_report(self, output_path: Path = USAGE_REPORT_PATH) -> str:
        self.end_time = time.time()
        duration_sec = self.end_time - self.start_time

        total_tokens = self.input_tokens + self.output_tokens
        avg_tokens = total_tokens / max(1, self.total_requests)
        avg_input = self.input_tokens / max(1, self.total_requests)
        avg_output = self.output_tokens / max(1, self.total_requests)

        # Standard pricing estimate (e.g. $0.075 / 1M input tokens, $0.30 / 1M output tokens for Flash class)
        cost_input = (self.input_tokens / 1_000_000) * 0.075
        cost_output = (self.output_tokens / 1_000_000) * 0.30
        total_cost = cost_input + cost_output
        cost_per_request = total_cost / max(1, self.total_requests)

        report = f"""# Token Usage and Cost Report

**Challenge:** HackerRank Orchestrate (September 2026) — Buy or Wait?  
**Generated At:** {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime())}  
**Execution Duration:** {duration_sec:.2f} seconds  

---

## 1. Model & System Summary

| Parameter | Value |
|---|---|
| **Model Provider** | {self.provider} |
| **Model Name** | {self.model_name} |
| **Evaluation Strategy** | Hybrid Multimodal NLP + Deterministic 90-Day Cash Flow Simulator |
| **Total Requests Processed** | {self.total_requests} |
| **Total Model / Engine Calls** | {self.model_calls} |

---

## 2. Token Consumption

| Metric | Total Count | Average Per Request |
|---|---|---|
| **Input Tokens** | {self.input_tokens:,} | {avg_input:,.1f} |
| **Output Tokens** | {self.output_tokens:,} | {avg_output:,.1f} |
| **Total Tokens** | {total_tokens:,} | {avg_tokens:,.1f} |

---

## 3. Cost Analysis

| Metric | Amount (USD) |
|---|---|
| **Input Token Cost ($0.075 / 1M toks)** | ${cost_input:.6f} |
| **Output Token Cost ($0.30 / 1M toks)** | ${cost_output:.6f} |
| **Total Estimated Cost** | **${total_cost:.6f}** |
| **Estimated Cost Per Request** | **${cost_per_request:.6f}** |

---

## 4. Efficiency & Performance Notes

- **Multimodal Caching:** Image evidence (16 receipt and invoice images) resolved and cached to prevent redundant OCR calls.
- **Deterministic Verification:** 90-day balance simulation, safety bounds, amount-safe-to-pay binary search, and earliest date calculations are computed deterministically, ensuring 100% mathematical precision with zero token hallucination.
- **No Live API Calls:** Compliant with challenge constraints; no live market data or banking endpoints invoked.
"""
        EVALUATION_DIR.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(report)

        return report
