"""
Dataclasses and schemas for Buy or Wait financial decision agent.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from datetime import datetime


@dataclass
class FinancialProfile:
    user_id: str
    home_currency: str
    current_available_balance: float
    minimum_balance_to_keep: float
    financial_priorities: List[str]
    expense_categories_to_protect: List[str]
    expense_categories_user_is_willing_to_reduce: List[str]
    expense_categories_user_is_willing_to_stop: List[str]
    payment_methods_user_will_consider: List[str]
    max_installment_months: Optional[int]


@dataclass
class FinancialEvent:
    event_id: str
    user_id: str
    event_type: str
    description: str
    category: str
    direction: str  # 'debit' or 'credit'
    amount: float
    currency: str
    event_date: str  # YYYY-MM-DD
    settlement_date: str  # YYYY-MM-DD
    status: str  # 'settled', 'pending', 'scheduled', 'cancelled', 'failed', 'unrealized'
    linked_event_id: Optional[str]
    flexibility: str  # 'fixed', 'reducible', 'stoppable', 'reducible_or_stoppable'
    minimum_allowed_amount: Optional[float]


@dataclass
class SpendingRequest:
    request_id: str
    user_id: str
    request_date: str
    request_type: str
    requested_amount: float
    desired_completion_date: str
    allows_partial_payment: bool
    request_text: str


@dataclass
class PaymentOption:
    payment_option_id: str
    request_id: str
    payment_method: str  # 'full_payment', 'installments', etc.
    payment_amount: float
    number_of_payments: int
    first_payment_date: str
    payment_frequency_days: Optional[int]
    financing_fee: float
    total_payable_amount: float


@dataclass
class MessageRecord:
    message_id: str
    user_id: str
    request_id: Optional[str]
    related_event_id: Optional[str]
    sent_at: str
    source_type: str
    message_text: str


@dataclass
class SpendingChangeAction:
    action_type: str  # 'stop' or 'reduce_to'
    event_id: str
    new_amount: Optional[float] = None

    def to_string(self) -> str:
        if self.action_type == 'stop':
            return f"stop:{self.event_id}"
        elif self.action_type == 'reduce_to':
            # Format float nicely without trailing unnecessary decimals if integer
            amt_str = f"{self.new_amount:g}" if self.new_amount is not None else "0"
            return f"reduce_to:{self.event_id}:{amt_str}"
        return ""


@dataclass
class PlanCandidate:
    affordability_status: str
    recommended_payment_method: str
    payment_plan: str
    earliest_date_for_full_payment: str
    spending_changes_needed: str
    decision_explanation: str
    amount_safe_to_pay: float
    
    # Internal sorting metrics
    completes_by_deadline: bool = True
    spending_changes_count: int = 0
    total_cost: float = 0.0
    start_date: str = ""
    num_payments: int = 1
    payment_option_id: str = "zzzz"
