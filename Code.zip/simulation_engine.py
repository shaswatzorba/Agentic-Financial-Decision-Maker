"""
90-day conservative cash flow simulation engine.
Highly optimized vector balance projection for fast deterministic calculation.
"""

from typing import List, Dict, Tuple, Optional, Set
from datetime import datetime, timedelta
from collections import defaultdict
import math

from .models import (
    FinancialProfile,
    FinancialEvent,
    SpendingChangeAction,
    SpendingRequest
)
from .message_parser import ParsedMessageInfo
from .data_loader import DataLoader


class SimulationEngine:
    def __init__(self, data_loader: DataLoader):
        self.data_loader = data_loader

    def build_recurring_schedule(
        self,
        profile: FinancialProfile,
        events: List[FinancialEvent],
        parsed_msg: ParsedMessageInfo,
        req_date: datetime,
        spending_changes: Optional[List[SpendingChangeAction]] = None,
        days: int = 90
    ) -> Dict[str, List[Tuple[str, float, str, str]]]:
        """
        Builds a day-by-day cash flow schedule (date_str -> list of (direction, amount, category, event_id)).
        """
        schedule = defaultdict(list)
        req_date_str = req_date.strftime("%Y-%m-%d")
        end_date = req_date + timedelta(days=days)
        end_date_str = end_date.strftime("%Y-%m-%d")

        # Map spending changes
        stop_events = set()
        reduce_events = {}
        if spending_changes:
            for sc in spending_changes:
                if sc.action_type == 'stop':
                    stop_events.add(sc.event_id)
                elif sc.action_type == 'reduce_to' and sc.new_amount is not None:
                    reduce_events[sc.event_id] = sc.new_amount

        # 1. Process future scheduled/pending events already present in dataset
        for ev in events:
            rate = self.data_loader.get_exchange_rate(
                ev.settlement_date or ev.event_date,
                ev.currency,
                profile.home_currency
            )
            amt_home = ev.amount * rate

            # Pending debit
            if ev.status == 'pending' and ev.direction == 'debit':
                s_date = max(ev.settlement_date or ev.event_date, req_date_str)
                if s_date <= end_date_str:
                    schedule[s_date].append(('debit', amt_home, ev.category, ev.event_id))

            # Scheduled debit
            elif ev.status == 'scheduled' and ev.direction == 'debit':
                s_date = ev.settlement_date or ev.event_date
                if req_date_str <= s_date <= end_date_str:
                    if ev.event_id in stop_events:
                        continue
                    elif ev.event_id in reduce_events:
                        reduced_amt = reduce_events[ev.event_id] * rate
                        schedule[s_date].append(('debit', reduced_amt, ev.category, ev.event_id))
                    else:
                        schedule[s_date].append(('debit', amt_home, ev.category, ev.event_id))

            # Scheduled credit (only confirmed salary)
            elif ev.status == 'scheduled' and ev.direction == 'credit' and ev.category == 'salary':
                s_date = ev.settlement_date or ev.event_date
                if req_date_str <= s_date <= end_date_str:
                    if not parsed_msg.salary_ended:
                        sal_amt = amt_home
                        if parsed_msg.salary_override_amount is not None:
                            sal_rate = self.data_loader.get_exchange_rate(
                                s_date,
                                parsed_msg.salary_currency or ev.currency,
                                profile.home_currency
                            )
                            sal_amt = parsed_msg.salary_override_amount * sal_rate
                        schedule[s_date].append(('credit', sal_amt, 'salary', ev.event_id))

        # 2. Extract recurring streams from past settled events
        past_events = [e for e in events if e.event_date <= req_date_str and e.status == 'settled']
        monthly_groups = defaultdict(list)
        weekly_groups = defaultdict(list)

        for e in past_events:
            if e.category in ('windfall', 'investment'):
                continue
            if e.category in ('rent', 'salary', 'utilities', 'debt_repayment', 'family_support',
                             'insurance', 'education', 'cloud_storage', 'streaming',
                             'music_subscription', 'delivery_membership', 'gym', 'shopping', 'entertainment', 'housing'):
                monthly_groups[(e.category, e.description, e.direction, e.flexibility)].append(e)
            elif e.category in ('groceries', 'transport', 'dining'):
                weekly_groups[(e.category, e.description, e.direction, e.flexibility)].append(e)

        # 2a. Monthly Streams
        scheduled_salary_dates = {d for d, items in schedule.items() for item in items if item[2] == 'salary'}

        for (cat, desc, direction, flex), ev_list in monthly_groups.items():
            if not ev_list:
                continue
            sorted_evs = sorted(ev_list, key=lambda x: x.event_date)
            latest_ev = sorted_evs[-1]
            last_dt = datetime.strptime(latest_ev.event_date, "%Y-%m-%d")
            dom = last_dt.day

            base_amt = latest_ev.amount
            rate = self.data_loader.get_exchange_rate(req_date_str, latest_ev.currency, profile.home_currency)
            base_amt_home = base_amt * rate

            if cat == 'rent' and parsed_msg.rent_increase_percent is not None:
                base_amt_home *= (1.0 + parsed_msg.rent_increase_percent / 100.0)

            if cat == 'salary':
                if parsed_msg.salary_ended:
                    continue
                if parsed_msg.salary_override_amount is not None:
                    sal_rate = self.data_loader.get_exchange_rate(
                        req_date_str,
                        parsed_msg.salary_currency or latest_ev.currency,
                        profile.home_currency
                    )
                    base_amt_home = parsed_msg.salary_override_amount * sal_rate
                if parsed_msg.salary_effective_date:
                    eff_dt = datetime.strptime(parsed_msg.salary_effective_date, "%Y-%m-%d")
                    dom = eff_dt.day

            for m in range(0, 4):
                proj_year = req_date.year
                proj_month = req_date.month + m
                while proj_month > 12:
                    proj_month -= 12
                    proj_year += 1

                days_in_m = [31,
                    29 if proj_year % 4 == 0 and not (proj_year % 100 == 0 and proj_year % 400 != 0) else 28,
                    31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
                p_day = min(dom, days_in_m[proj_month - 1])
                proj_dt = datetime(proj_year, proj_month, p_day)
                proj_date_str = proj_dt.strftime("%Y-%m-%d")

                if req_date_str <= proj_date_str <= end_date_str:
                    if cat == 'salary' and proj_date_str in scheduled_salary_dates:
                        continue

                    if latest_ev.event_id in stop_events:
                        continue
                    elif latest_ev.event_id in reduce_events:
                        reduced_amt = reduce_events[latest_ev.event_id] * rate
                        schedule[proj_date_str].append((direction, reduced_amt, cat, latest_ev.event_id))
                    else:
                        schedule[proj_date_str].append((direction, base_amt_home, cat, latest_ev.event_id))

        # 2b. Weekly Streams
        for (cat, desc, direction, flex), ev_list in weekly_groups.items():
            if not ev_list:
                continue
            sorted_evs = sorted(ev_list, key=lambda x: x.event_date)
            latest_ev = sorted_evs[-1]
            last_dt = datetime.strptime(latest_ev.event_date, "%Y-%m-%d")

            if len(sorted_evs) >= 2:
                intervals = [(datetime.strptime(sorted_evs[i+1].event_date, "%Y-%m-%d") - datetime.strptime(sorted_evs[i].event_date, "%Y-%m-%d")).days for i in range(len(sorted_evs)-1)]
                avg_int = max(1, round(sum(intervals) / len(intervals)))
            else:
                avg_int = 7

            base_amt = latest_ev.amount
            rate = self.data_loader.get_exchange_rate(req_date_str, latest_ev.currency, profile.home_currency)
            base_amt_home = base_amt * rate

            curr_dt = last_dt + timedelta(days=avg_int)
            while curr_dt <= end_date:
                curr_date_str = curr_dt.strftime("%Y-%m-%d")
                if curr_date_str >= req_date_str:
                    if latest_ev.event_id in stop_events:
                        pass
                    elif latest_ev.event_id in reduce_events:
                        reduced_amt = reduce_events[latest_ev.event_id] * rate
                        schedule[curr_date_str].append((direction, reduced_amt, cat, latest_ev.event_id))
                    else:
                        schedule[curr_date_str].append((direction, base_amt_home, cat, latest_ev.event_id))
                curr_dt += timedelta(days=avg_int)

        return schedule

    def build_base_balances(
        self,
        profile: FinancialProfile,
        events: List[FinancialEvent],
        parsed_msg: ParsedMessageInfo,
        req_date: datetime,
        spending_changes: Optional[List[SpendingChangeAction]] = None,
        days: int = 90
    ) -> List[float]:
        """
        Computes the daily ending balance vector [day 0, day 1, ..., day 90]
        before any plan payments.
        """
        schedule = self.build_recurring_schedule(
            profile, events, parsed_msg, req_date, spending_changes, days
        )
        curr_bal = profile.current_available_balance
        balances = []

        for d in range(0, days + 1):
            curr_dt = req_date + timedelta(days=d)
            curr_date_str = curr_dt.strftime("%Y-%m-%d")

            if curr_date_str in schedule:
                for direction, amt, cat, ev_id in schedule[curr_date_str]:
                    if direction == 'credit':
                        curr_bal += amt
                    elif direction == 'debit':
                        curr_bal -= amt
            balances.append(curr_bal)

        return balances

    def simulate_plan(
        self,
        profile: FinancialProfile,
        events: List[FinancialEvent],
        parsed_msg: ParsedMessageInfo,
        req_date: datetime,
        payment_items: List[Tuple[str, float]],
        spending_changes: Optional[List[SpendingChangeAction]] = None,
        days: int = 90
    ) -> Tuple[bool, float, List[float]]:
        """
        Simulates plan payments on top of base trajectory.
        """
        base_balances = self.build_base_balances(
            profile, events, parsed_msg, req_date, spending_changes, days
        )
        balances = list(base_balances)

        for date_str, amt in payment_items:
            try:
                p_dt = datetime.strptime(date_str, "%Y-%m-%d")
                d_idx = (p_dt - req_date).days
            except Exception:
                d_idx = 0

            if 0 <= d_idx <= days:
                for d in range(d_idx, days + 1):
                    balances[d] -= amt

        min_bal = min(balances)
        is_safe = round(min_bal, 2) >= round(profile.minimum_balance_to_keep, 2)
        return is_safe, min_bal, balances

    def compute_amount_safe_to_pay(
        self,
        profile: FinancialProfile,
        events: List[FinancialEvent],
        parsed_msg: ParsedMessageInfo,
        req_date: datetime,
        requested_amount: float,
        days: int = 90
    ) -> float:
        """
        Calculates amount safe to pay today in closed-form.
        Safe = max(0, min(requested_amount, min(base_balances) - minimum_balance_to_keep)).
        """
        base_balances = self.build_base_balances(
            profile, events, parsed_msg, req_date, None, days
        )
        min_base = min(base_balances)
        surplus = min_base - profile.minimum_balance_to_keep
        safe_val = max(0.0, min(requested_amount, surplus))
        safe_val = round(safe_val, 2)
        if abs(safe_val - round(safe_val)) < 1e-4:
            safe_val = round(safe_val)
        return safe_val

    def compute_earliest_date_for_full_payment(
        self,
        profile: FinancialProfile,
        events: List[FinancialEvent],
        parsed_msg: ParsedMessageInfo,
        req_date: datetime,
        requested_amount: float,
        days: int = 90
    ) -> str:
        """
        Finds earliest date where a single full payment is safe without spending changes.
        """
        base_balances = self.build_base_balances(
            profile, events, parsed_msg, req_date, None, days
        )
        min_keep = profile.minimum_balance_to_keep

        # Prefix min balances (before payment date)
        prefix_min = [base_balances[0]] * (days + 1)
        for d in range(1, days + 1):
            prefix_min[d] = min(prefix_min[d - 1], base_balances[d])

        # Suffix min balances (from payment date onwards)
        suffix_min = [base_balances[-1]] * (days + 1)
        for d in range(days - 1, -1, -1):
            suffix_min[d] = min(suffix_min[d + 1], base_balances[d])

        for d in range(0, days + 1):
            # Check before day d: min balance >= min_keep
            if d > 0 and round(prefix_min[d - 1], 2) < round(min_keep, 2):
                # If already breached before day d, earlier days were unsafe
                pass
            
            # Check from day d onwards: suffix_min[d] - requested_amount >= min_keep
            if round(suffix_min[d] - requested_amount, 2) >= round(min_keep, 2):
                if d == 0 or round(prefix_min[d - 1], 2) >= round(min_keep, 2):
                    curr_dt = req_date + timedelta(days=d)
                    return curr_dt.strftime("%Y-%m-%d")

        return ""
