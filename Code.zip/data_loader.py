"""
Data loading, preprocessing, currency conversion, and multimodal evidence resolution.
"""

import csv
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from datetime import datetime

from .config import (
    DATASET_DIR,
    IMAGE_AMOUNTS
)
from .models import (
    FinancialProfile,
    FinancialEvent,
    SpendingRequest,
    PaymentOption,
    MessageRecord
)


class DataLoader:
    def __init__(self, dataset_dir: Path = DATASET_DIR):
        self.dataset_dir = dataset_dir
        self.profiles: Dict[str, FinancialProfile] = {}
        self.events_by_user: Dict[str, List[FinancialEvent]] = {}
        self.all_events: Dict[str, FinancialEvent] = {}
        self.options_by_request: Dict[str, List[PaymentOption]] = {}
        self.messages_by_user: Dict[str, List[MessageRecord]] = {}
        self.messages_by_request: Dict[str, List[MessageRecord]] = {}
        self.exchange_rates: Dict[Tuple[str, str, str], float] = {}
        self.requests: List[SpendingRequest] = []
        self.sample_requests: List[Dict[str, str]] = []

    def load_all(self):
        self._load_exchange_rates()
        self._load_images_and_events()
        self._load_profiles()
        self._load_payment_options()
        self._load_messages()
        self._load_requests()
        self._load_sample_requests()

    def _load_exchange_rates(self):
        path = self.dataset_dir / "exchange_rates.csv"
        if not path.exists():
            return
        with open(path, "r", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                rate_date = row["rate_date"].strip()
                from_curr = row["from_currency"].strip()
                to_curr = row["to_currency"].strip()
                rate = float(row["rate"].strip())
                self.exchange_rates[(rate_date, from_curr, to_curr)] = rate
                # Also allow direct 1:1 if same currency
                self.exchange_rates[(rate_date, from_curr, from_curr)] = 1.0

    def get_exchange_rate(self, rate_date: str, from_curr: str, to_curr: str) -> float:
        if from_curr == to_curr:
            return 1.0
        if (rate_date, from_curr, to_curr) in self.exchange_rates:
            return self.exchange_rates[(rate_date, from_curr, to_curr)]
        # Check reciprocal if available
        if (rate_date, to_curr, from_curr) in self.exchange_rates:
            recip = self.exchange_rates[(rate_date, to_curr, from_curr)]
            if recip > 0:
                return 1.0 / recip
        return 1.0

    def _load_images_and_events(self):
        # 1. Map image_id to related_event_id
        img_event_map = {}
        img_path = self.dataset_dir / "images.csv"
        if img_path.exists():
            with open(img_path, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    img_id = row["image_id"].strip()
                    rel_ev = row["related_event_id"].strip()
                    if rel_ev and img_id in IMAGE_AMOUNTS:
                        img_event_map[rel_ev] = IMAGE_AMOUNTS[img_id]

        # 2. Load financial events
        ev_path = self.dataset_dir / "financial_events.csv"
        with open(ev_path, "r", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                ev_id = row["event_id"].strip()
                user_id = row["user_id"].strip()
                amt_str = row["amount"].strip()
                if amt_str:
                    amt = float(amt_str)
                elif ev_id in img_event_map:
                    amt = img_event_map[ev_id]
                else:
                    amt = 0.0

                min_amt_str = row["minimum_allowed_amount"].strip()
                min_amt = float(min_amt_str) if min_amt_str else None

                event = FinancialEvent(
                    event_id=ev_id,
                    user_id=user_id,
                    event_type=row["event_type"].strip(),
                    description=row["description"].strip(),
                    category=row["category"].strip(),
                    direction=row["direction"].strip(),
                    amount=amt,
                    currency=row["currency"].strip(),
                    event_date=row["event_date"].strip(),
                    settlement_date=row["settlement_date"].strip() or row["event_date"].strip(),
                    status=row["status"].strip(),
                    linked_event_id=row["linked_event_id"].strip() or None,
                    flexibility=row["flexibility"].strip(),
                    minimum_allowed_amount=min_amt
                )
                self.all_events[ev_id] = event
                if user_id not in self.events_by_user:
                    self.events_by_user[user_id] = []
                self.events_by_user[user_id].append(event)

    def _load_profiles(self):
        path = self.dataset_dir / "financial_profiles.csv"
        with open(path, "r", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                uid = row["user_id"].strip()
                max_inst_str = row["max_installment_months"].strip()
                max_inst = int(max_inst_str) if max_inst_str else None

                def parse_list(val: str) -> List[str]:
                    return [x.strip() for x in val.split("|") if x.strip()] if val else []

                profile = FinancialProfile(
                    user_id=uid,
                    home_currency=row["home_currency"].strip(),
                    current_available_balance=float(row["current_available_balance"].strip()),
                    minimum_balance_to_keep=float(row["minimum_balance_to_keep"].strip()),
                    financial_priorities=parse_list(row["financial_priorities"]),
                    expense_categories_to_protect=parse_list(row["expense_categories_to_protect"]),
                    expense_categories_user_is_willing_to_reduce=parse_list(row["expense_categories_user_is_willing_to_reduce"]),
                    expense_categories_user_is_willing_to_stop=parse_list(row["expense_categories_user_is_willing_to_stop"]),
                    payment_methods_user_will_consider=parse_list(row["payment_methods_user_will_consider"]),
                    max_installment_months=max_inst
                )
                self.profiles[uid] = profile

    def _load_payment_options(self):
        path = self.dataset_dir / "request_payment_options.csv"
        if not path.exists():
            return
        with open(path, "r", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                req_id = row["request_id"].strip()
                freq_str = row["payment_frequency_days"].strip()
                freq = int(freq_str) if freq_str else 0
                opt = PaymentOption(
                    payment_option_id=row["payment_option_id"].strip(),
                    request_id=req_id,
                    payment_method=row["payment_method"].strip(),
                    payment_amount=float(row["payment_amount"].strip()),
                    number_of_payments=int(row["number_of_payments"].strip()),
                    first_payment_date=row["first_payment_date"].strip(),
                    payment_frequency_days=freq,
                    financing_fee=float(row["financing_fee"].strip()),
                    total_payable_amount=float(row["total_payable_amount"].strip())
                )
                if req_id not in self.options_by_request:
                    self.options_by_request[req_id] = []
                self.options_by_request[req_id].append(opt)

    def _load_messages(self):
        path = self.dataset_dir / "messages.csv"
        if not path.exists():
            return
        with open(path, "r", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                uid = row["user_id"].strip()
                req_id = row["request_id"].strip() or None
                ev_id = row["related_event_id"].strip() or None
                msg = MessageRecord(
                    message_id=row["message_id"].strip(),
                    user_id=uid,
                    request_id=req_id,
                    related_event_id=ev_id,
                    sent_at=row["sent_at"].strip(),
                    source_type=row["source_type"].strip(),
                    message_text=row["message_text"].strip()
                )
                if uid not in self.messages_by_user:
                    self.messages_by_user[uid] = []
                self.messages_by_user[uid].append(msg)
                if req_id:
                    if req_id not in self.messages_by_request:
                        self.messages_by_request[req_id] = []
                    self.messages_by_request[req_id].append(msg)

    def _load_requests(self):
        path = self.dataset_dir / "requests.csv"
        with open(path, "r", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                allow_part = row["allows_partial_payment"].strip().lower() in ("true", "1", "yes")
                req = SpendingRequest(
                    request_id=row["request_id"].strip(),
                    user_id=row["user_id"].strip(),
                    request_date=row["request_date"].strip(),
                    request_type=row["request_type"].strip(),
                    requested_amount=float(row["requested_amount"].strip()),
                    desired_completion_date=row["desired_completion_date"].strip(),
                    allows_partial_payment=allow_part,
                    request_text=row["request_text"].strip()
                )
                self.requests.append(req)

    def _load_sample_requests(self):
        path = self.dataset_dir / "sample_requests.csv"
        if not path.exists():
            return
        with open(path, "r", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                self.sample_requests.append(row)
