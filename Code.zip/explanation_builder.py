"""
Explanation builder for creating grounded, concise decision explanations.
"""

from typing import List, Dict, Optional
from datetime import datetime

from .models import (
    PlanCandidate,
    SpendingRequest,
    FinancialProfile,
    FinancialEvent,
    PaymentOption
)


def format_currency_amount(amount: float, currency: str) -> str:
    """Formats amount with currency symbol or code and comma separators."""
    if abs(amount - round(amount)) < 1e-4:
        amt_str = f"{int(round(amount)):,}"
    else:
        amt_str = f"{amount:,.2f}"
    return f"{currency} {amt_str}"


def format_date_human(date_str: str) -> str:
    """Converts '2025-08-08' -> '8 August 2025'."""
    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        # %d without leading zero if possible
        day = dt.day
        month_name = dt.strftime("%B")
        year = dt.year
        return f"{day} {month_name} {year}"
    except Exception:
        return date_str


class ExplanationBuilder:
    def __init__(self, all_events: Dict[str, FinancialEvent]):
        self.all_events = all_events

    def build_explanation(
        self,
        plan: PlanCandidate,
        request: SpendingRequest,
        profile: FinancialProfile,
        min_balance_remaining: float
    ) -> str:
        curr = profile.home_currency
        min_bal_str = format_currency_amount(profile.minimum_balance_to_keep, curr)
        req_amt_str = format_currency_amount(request.requested_amount, curr)
        safe_amt_str = format_currency_amount(plan.amount_safe_to_pay, curr)
        deadline_str = format_date_human(request.desired_completion_date)

        # 1. Full payment affordable now
        if plan.recommended_payment_method == "full_payment" and plan.spending_changes_needed == "none":
            return f"Pay {req_amt_str} today. This leaves at least {min_bal_str} available over the next 90 days."

        # 2. Full payment with spending changes
        if plan.recommended_payment_method == "full_payment" and plan.spending_changes_needed != "none":
            sc_parts = self._describe_spending_changes(plan.spending_changes_needed, curr)
            return f"{sc_parts}, then pay {req_amt_str} today. This leaves at least {min_bal_str} available."

        # 3. Partial payment
        if plan.recommended_payment_method == "partial_payment":
            rem_amt = request.requested_amount - plan.amount_safe_to_pay
            rem_amt_str = format_currency_amount(rem_amt, curr)
            earliest_dt_str = format_date_human(plan.earliest_date_for_full_payment)
            return f"Pay {safe_amt_str} today and the remaining {rem_amt_str} on {earliest_dt_str}. This completes the full request and keeps the {min_bal_str} minimum protected."

        # 4. Installments
        if plan.recommended_payment_method == "installments":
            # Extract number of payments, payment amount, start date from plan
            payments = plan.payment_plan.split("|")
            num_payments = len(payments)
            first_p = payments[0].split(":")
            first_date_str = format_date_human(first_p[0])
            first_amt = float(first_p[1])
            first_amt_str = format_currency_amount(first_amt, curr)

            if plan.spending_changes_needed == "none":
                return f"Use {num_payments} installments of {first_amt_str}, starting {first_date_str}. This leaves at least {min_bal_str} available."
            else:
                sc_parts = self._describe_spending_changes(plan.spending_changes_needed, curr)
                return f"{sc_parts}, then use {num_payments} installments of {first_amt_str}, starting {first_date_str}. This leaves at least {min_bal_str} available."

        # 5. Wait
        if plan.recommended_payment_method == "wait":
            earliest_dt_str = format_date_human(plan.earliest_date_for_full_payment)
            return f"Pay {req_amt_str} in full on {earliest_dt_str}. Paying earlier would take the balance below the {min_bal_str} minimum."

        # 6. Not recommended
        if plan.recommended_payment_method == "not_recommended":
            if plan.amount_safe_to_pay > 0:
                return f"Do not proceed with the {req_amt_str} request. Although {safe_amt_str} is available today, the full amount cannot be completed safely within 90 days."
            else:
                return f"Do not make this payment by {deadline_str}. None of the available options keeps the {min_bal_str} minimum protected."

        return f"Unable to safely recommend payment of {req_amt_str} while maintaining the {min_bal_str} minimum balance."

    def _describe_spending_changes(self, sc_str: str, curr: str) -> str:
        actions = sc_str.split("|")
        descriptions = []
        for act in actions:
            parts = act.split(":")
            if parts[0] == "stop":
                ev_id = parts[1]
                ev = self.all_events.get(ev_id)
                ev_name = ev.description.lower() if ev else "the subscription"
                descriptions.append(f"Stop the {ev_name}")
            elif parts[0] == "reduce_to":
                ev_id = parts[1]
                ev = self.all_events.get(ev_id)
                ev_name = ev.description.lower() if ev else "the expense"
                new_amt = float(parts[2])
                new_amt_str = format_currency_amount(new_amt, curr)
                descriptions.append(f"Reduce the {ev_name} to {new_amt_str}")

        if len(descriptions) == 1:
            return descriptions[0]
        elif len(descriptions) == 2:
            return f"{descriptions[0]} and {descriptions[1][0].lower() + descriptions[1][1:]}"
        else:
            return f"{descriptions[0]}, {descriptions[1][0].lower() + descriptions[1][1:]}, and {descriptions[2][0].lower() + descriptions[2][1:]}"
