"""
Buy or Wait? - AI Financial Decision Agent
HackerRank Orchestrate September 2026
"""

__version__ = "1.0.0"
