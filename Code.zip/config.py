"""
Configuration, constants, and static lookup mappings for Buy or Wait financial decision agent.
"""

from pathlib import Path

# Paths
REPO_ROOT = Path(__file__).resolve().parent.parent
DATASET_DIR = REPO_ROOT / "dataset"
MEDIA_IMAGES_DIR = DATASET_DIR / "media" / "images"
EVALUATION_DIR = REPO_ROOT / "evaluation"
OUTPUT_CSV_PATH = DATASET_DIR / "output.csv"
FINAL_OUTPUT_CSV_PATH = REPO_ROOT / "output.csv"
USAGE_REPORT_PATH = EVALUATION_DIR / "usage_report.md"

# Output Schema
OUTPUT_COLUMNS = [
    "request_id",
    "amount_safe_to_pay",
    "affordability_status",
    "recommended_payment_method",
    "payment_plan",
    "earliest_date_for_full_payment",
    "spending_changes_needed",
    "decision_explanation"
]

# Allowed Enums
AFFORDABILITY_STATUSES = [
    "affordable_now",
    "affordable_with_plan",
    "affordable_later",
    "not_affordable"
]

RECOMMENDED_PAYMENT_METHODS = [
    "full_payment",
    "partial_payment",
    "installments",
    "wait",
    "not_recommended"
]

# Supported Currencies
SUPPORTED_CURRENCIES = ["INR", "ZAR", "IDR", "USD", "EUR"]

# Verified amounts extracted from multimodal evidence images (dataset/media/images/<image_id>.png)
IMAGE_AMOUNTS = {
    "image_01": 4365000.0,   # Net salary IDR 4,365,000 (payslip)
    "image_02": 100000.0,    # Outstanding rent balance INR 100,000.00 (rent receipt)
    "image_03": 41272.0,     # Groceries bill net amount INR 41,272.00
    "image_04": 2854.0,      # Delivered grocery order total bill INR 2,854.00
    "image_05": 704.05,      # Telecom bill amount due INR 704.05
    "image_06": 1995.0,      # Grocery invoice total INR 1,995.00
    "image_07": 8528.0,      # Restaurant tax invoice grand total INR 8,528.00
    "image_08": 15339.0,     # Property maintenance invoice total INR 15,339.00
    "image_09": 723.0,       # Water bill total INR 723.00
    "image_10": 79679.26,    # Grocery invoice balance due INR 79,679.26
    "image_11": 3650.0,      # Hospital bill payable INR 3,650.00
    "image_12": 33.50,       # Taxi fare total USD 33.50
    "image_13": 2298.0,      # Tote bag order total paid INR 2,298.00
    "image_14": 4543.0,      # Pharmacy purchase total INR 4,543.00
    "image_15": 9968.0,      # Airline ticket purchase total INR 9,968.00
    "image_16": 393.22       # EV charging wallet payment total INR 393.22
}
