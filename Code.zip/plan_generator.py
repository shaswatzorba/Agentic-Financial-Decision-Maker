"""
Plan generator for creating and evaluating all candidate financial plans.
Optimized for performance and strict compliance with ranking hierarchy.
"""

import math
from typing import List, Dict, Tuple, Optional, Set
from datetime import datetime, timedelta
import itertools
from collections import defaultdict

from .models import (
    SpendingRequest,
    FinancialProfile,
    FinancialEvent,
    PaymentOption,
    SpendingChangeAction,
    PlanCandidate
)
from .message_parser import ParsedMessageInfo
from .simulation_engine import SimulationEngine
from .plan_ranker import PlanRanker


class PlanGenerator:
    def __init__(self, simulation_engine: SimulationEngine):
        self.sim_engine = simulation_engine

    def generate_spending_change_combinations(
        self,
        profile: FinancialProfile,
        events: List[FinancialEvent],
        req_date: datetime
    ) -> List[List[SpendingChangeAction]]:
        """
        Generates valid spending change sets (up to 3 actions) targeting
        only the latest active flexible events the user is willing to adjust and not protect.
        """
        # Find latest event per category
        latest_by_cat: Dict[str, FinancialEvent] = {}
        past_events = [e for e in events if e.event_date <= req_date.strftime("%Y-%m-%d")]
        for ev in sorted(past_events, key=lambda x: x.event_date):
            latest_by_cat[ev.category] = ev

        available_actions: List[SpendingChangeAction] = []
        for cat, ev in latest_by_cat.items():
            if cat in profile.expense_categories_to_protect:
                continue

            # Stoppable
            if cat in profile.expense_categories_user_is_willing_to_stop and ev.flexibility in ('stoppable', 'reducible_or_stoppable'):
                available_actions.append(SpendingChangeAction('stop', ev.event_id))

            # Reducible
            elif cat in profile.expense_categories_user_is_willing_to_reduce and ev.flexibility in ('reducible', 'reducible_or_stoppable'):
                min_amt = ev.minimum_allowed_amount if ev.minimum_allowed_amount is not None else 0.0
                available_actions.append(SpendingChangeAction('reduce_to', ev.event_id, min_amt))

        combos = []
        # 1 action
        for a in available_actions:
            combos.append([a])
        # 2 actions
        for a1, a2 in itertools.combinations(available_actions, 2):
            if a1.event_id != a2.event_id:
                combos.append([a1, a2])
        # 3 actions
        for a1, a2, a3 in itertools.combinations(available_actions, 3):
            if len({a1.event_id, a2.event_id, a3.event_id}) == 3:
                combos.append([a1, a2, a3])

        return combos

    def format_amount(self, val: float) -> str:
        """Formats amount cleanly: e.g. 25256 or 15952906.67 or 620.40"""
        if abs(val - round(val)) < 1e-4:
            return f"{int(round(val))}"
        return f"{val:.2f}"

    def build_installment_schedule(self, opt: PaymentOption) -> List[Tuple[str, float]]:
        """Constructs the list of (date_str, amount) for an installment option."""
        payments = []
        start_dt = datetime.strptime(opt.first_payment_date, "%Y-%m-%d")
        freq = opt.payment_frequency_days if opt.payment_frequency_days > 0 else 30
        for i in range(opt.number_of_payments):
            p_dt = start_dt + timedelta(days=i * freq)
            payments.append((p_dt.strftime("%Y-%m-%d"), opt.payment_amount))
        return payments

    def evaluate_request(
        self,
        request: SpendingRequest,
        profile: FinancialProfile,
        events: List[FinancialEvent],
        options: List[PaymentOption],
        parsed_msg: ParsedMessageInfo
    ) -> PlanCandidate:
        req_date = datetime.strptime(request.request_date, "%Y-%m-%d")
        req_date_str = request.request_date
        req_amt = request.requested_amount
        completion_date_str = request.desired_completion_date

        # 1. Compute amount_safe_to_pay on req_date before spending changes
        amount_safe = self.sim_engine.compute_amount_safe_to_pay(
            profile, events, parsed_msg, req_date, req_amt
        )

        # 2. Compute earliest_date_for_full_payment without spending changes
        earliest_full_date = self.sim_engine.compute_earliest_date_for_full_payment(
            profile, events, parsed_msg, req_date, req_amt
        )

        candidates: List[PlanCandidate] = []

        # -------------------------------------------------------------
        # Option A: Full Payment Today
        # -------------------------------------------------------------
        if "full_payment" in profile.payment_methods_user_will_consider:
            # A1: Without spending changes
            is_safe, min_bal, _ = self.sim_engine.simulate_plan(
                profile, events, parsed_msg, req_date, [(req_date_str, req_amt)], None
            )
            if is_safe:
                cand = PlanCandidate(
                    affordability_status="affordable_now",
                    recommended_payment_method="full_payment",
                    payment_plan=f"{req_date_str}:{self.format_amount(req_amt)}",
                    earliest_date_for_full_payment=req_date_str,
                    spending_changes_needed="none",
                    decision_explanation="",
                    amount_safe_to_pay=amount_safe,
                    completes_by_deadline=(req_date_str <= completion_date_str),
                    spending_changes_count=0,
                    total_cost=req_amt,
                    start_date=req_date_str,
                    num_payments=1,
                    payment_option_id="opt_full_0"
                )
                candidates.append(cand)
            else:
                # A2: With spending changes (only if not already safe)
                spending_combos = self.generate_spending_change_combinations(profile, events, req_date)
                for combo in spending_combos:
                    is_safe_sc, _, _ = self.sim_engine.simulate_plan(
                        profile, events, parsed_msg, req_date, [(req_date_str, req_amt)], combo
                    )
                    if is_safe_sc:
                        sc_str = "|".join(c.to_string() for c in combo)
                        cand = PlanCandidate(
                            affordability_status="affordable_with_plan",
                            recommended_payment_method="full_payment",
                            payment_plan=f"{req_date_str}:{self.format_amount(req_amt)}",
                            earliest_date_for_full_payment=earliest_full_date,
                            spending_changes_needed=sc_str,
                            decision_explanation="",
                            amount_safe_to_pay=amount_safe,
                            completes_by_deadline=(req_date_str <= completion_date_str),
                            spending_changes_count=len(combo),
                            total_cost=req_amt,
                            start_date=req_date_str,
                            num_payments=1,
                            payment_option_id=f"opt_full_sc_{len(combo)}"
                        )
                        candidates.append(cand)
                        break  # Stop at shortest working combination

        # -------------------------------------------------------------
        # Option B: Partial Payment
        # -------------------------------------------------------------
        if (request.allows_partial_payment and
            "partial_payment" in profile.payment_methods_user_will_consider and
            0 < amount_safe < req_amt and
            earliest_full_date and
            earliest_full_date <= completion_date_str):
            
            p1_amt = amount_safe
            p2_amt = req_amt - amount_safe
            partial_payments = [(req_date_str, p1_amt), (earliest_full_date, p2_amt)]
            is_safe_part, _, _ = self.sim_engine.simulate_plan(
                profile, events, parsed_msg, req_date, partial_payments, None
            )
            if is_safe_part:
                plan_str = f"{req_date_str}:{self.format_amount(p1_amt)}|{earliest_full_date}:{self.format_amount(p2_amt)}"
                cand = PlanCandidate(
                    affordability_status="affordable_with_plan",
                    recommended_payment_method="partial_payment",
                    payment_plan=plan_str,
                    earliest_date_for_full_payment=earliest_full_date,
                    spending_changes_needed="none",
                    decision_explanation="",
                    amount_safe_to_pay=amount_safe,
                    completes_by_deadline=(earliest_full_date <= completion_date_str),
                    spending_changes_count=0,
                    total_cost=req_amt,
                    start_date=req_date_str,
                    num_payments=2,
                    payment_option_id="opt_partial"
                )
                candidates.append(cand)

        # -------------------------------------------------------------
        # Option C: Installments
        # -------------------------------------------------------------
        if "installments" in profile.payment_methods_user_will_consider:
            spending_combos = self.generate_spending_change_combinations(profile, events, req_date)
            # Only consider installment options from request_payment_options.csv with payment_method == 'installments'
            inst_options = [o for o in options if o.payment_method == "installments"]
            for opt in inst_options:
                freq = opt.payment_frequency_days if opt.payment_frequency_days > 0 else 30
                inst_days = (opt.number_of_payments - 1) * freq
                inst_months = math.ceil(inst_days / 30.0) if inst_days > 0 else 1
                if profile.max_installment_months is not None and inst_months > profile.max_installment_months:
                    continue

                payments = self.build_installment_schedule(opt)
                final_payment_date = payments[-1][0]
                plan_str = "|".join(f"{d}:{self.format_amount(a)}" for d, a in payments)

                # C1: Without spending changes
                is_safe_inst, _, _ = self.sim_engine.simulate_plan(
                    profile, events, parsed_msg, req_date, payments, None
                )
                if is_safe_inst:
                    cand = PlanCandidate(
                        affordability_status="affordable_with_plan",
                        recommended_payment_method="installments",
                        payment_plan=plan_str,
                        earliest_date_for_full_payment=earliest_full_date,
                        spending_changes_needed="none",
                        decision_explanation="",
                        amount_safe_to_pay=amount_safe,
                        completes_by_deadline=(final_payment_date <= completion_date_str),
                        spending_changes_count=0,
                        total_cost=opt.total_payable_amount,
                        start_date=opt.first_payment_date,
                        num_payments=opt.number_of_payments,
                        payment_option_id=opt.payment_option_id
                    )
                    candidates.append(cand)
                else:
                    # C2: With spending changes
                    for combo in spending_combos:
                        is_safe_inst_sc, _, _ = self.sim_engine.simulate_plan(
                            profile, events, parsed_msg, req_date, payments, combo
                        )
                        if is_safe_inst_sc:
                            sc_str = "|".join(c.to_string() for c in combo)
                            cand = PlanCandidate(
                                affordability_status="affordable_with_plan",
                                recommended_payment_method="installments",
                                payment_plan=plan_str,
                                earliest_date_for_full_payment=earliest_full_date,
                                spending_changes_needed=sc_str,
                                decision_explanation="",
                                amount_safe_to_pay=amount_safe,
                                completes_by_deadline=(final_payment_date <= completion_date_str),
                                spending_changes_count=len(combo),
                                total_cost=opt.total_payable_amount,
                                start_date=opt.first_payment_date,
                                num_payments=opt.number_of_payments,
                                payment_option_id=opt.payment_option_id
                            )
                            candidates.append(cand)
                            break

        # -------------------------------------------------------------
        # Option D: Wait
        # -------------------------------------------------------------
        if ("full_payment" in profile.payment_methods_user_will_consider and
            earliest_full_date and
            earliest_full_date > req_date_str):
            cand = PlanCandidate(
                affordability_status="affordable_later",
                recommended_payment_method="wait",
                payment_plan=f"{earliest_full_date}:{self.format_amount(req_amt)}",
                earliest_date_for_full_payment=earliest_full_date,
                spending_changes_needed="none",
                decision_explanation="",
                amount_safe_to_pay=amount_safe,
                completes_by_deadline=(earliest_full_date <= completion_date_str),
                spending_changes_count=0,
                total_cost=req_amt,
                start_date=earliest_full_date,
                num_payments=1,
                payment_option_id="opt_wait"
            )
            candidates.append(cand)

        # -------------------------------------------------------------
        # Select best plan via Ranker, or Fallback to Not Recommended
        # -------------------------------------------------------------
        if candidates:
            ranked = PlanRanker.rank_plans(candidates)
            best_plan = ranked[0]
            # If the best plan does not complete by deadline and is not 'wait', or violates key constraints:
            return best_plan

        # Fallback: Not Affordable / Not Recommended
        return PlanCandidate(
            affordability_status="not_affordable",
            recommended_payment_method="not_recommended",
            payment_plan="none",
            earliest_date_for_full_payment=earliest_full_date if earliest_full_date else "",
            spending_changes_needed="none",
            decision_explanation="",
            amount_safe_to_pay=amount_safe,
            completes_by_deadline=False,
            spending_changes_count=0,
            total_cost=0.0,
            start_date="",
            num_payments=0,
            payment_option_id="opt_none"
        )
